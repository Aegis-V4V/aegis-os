// Aegis OS | Terminal Feed Controller
// High-performance live stream and audit management

const liveFeed = document.getElementById('liveFeed');
const auditLog = document.getElementById('auditLog');
const headBlockText = document.getElementById('headBlock');
const jackpotPoolText = document.getElementById('jackpotPool');

const FEED_CAP = 100;
let feedItems = [];

/**
 * Appends a new podcast drop to the live feed.
 * @param {Object} drop - The podcast metadata.
 */
export function addPodcastDrop(drop) {
  // 1. Update Audit Log
  const timestamp = new Date().toLocaleTimeString();
  const logEntry = document.createElement('div');
  logEntry.className = 'log-entry';
  logEntry.innerHTML = `<span class="log-time">[${timestamp}]</span> Ingested: "${drop.title}"`;
  auditLog.prepend(logEntry);
  
  // Cap audit log to 50 entries
  if (auditLog.children.length > 50) {
    auditLog.removeChild(auditLog.lastChild);
  }

  // 2. Create Feed Card
  const card = document.createElement('div');
  card.className = 'podcast-card';
  
  // Logic for compliance tags
  const isCompliant = drop.isCompliant || false;
  const baselineScore = drop.baseline ? drop.baseline.omni : '---';
  const tagsHtml = isCompliant ? `<span class="tag">Aegis Verified</span> <span class="tag" style="background: var(--accent-blue);">Score: ${baselineScore}</span>` : '<span class="tag" style="color: #666;">Legacy Node</span>';

  card.innerHTML = `
    <img src="${drop.image || 'https://via.placeholder.com/80?text=Pod'}" class="podcast-art" alt="${drop.title}">
    <div class="podcast-info">
      <div class="podcast-title">${drop.title}</div>
      <div class="podcast-meta">
        ${tagsHtml}
        <span>${drop.description ? drop.description.substring(0, 60) + '...' : 'Live transmission captured.'}</span>
      </div>
    </div>
    <div class="podcast-actions">
      <button class="zap-btn" onclick="window.zapPodcast('${drop.url}')">ZAP</button>
    </div>
  `;

  // Prepend to feed and manage capacity
  if (liveFeed.firstChild && liveFeed.firstChild.classList.contains('placeholder')) {
    liveFeed.innerHTML = '';
  }
  
  liveFeed.prepend(card);
  feedItems.push(card);

  if (feedItems.length > FEED_CAP) {
    const oldest = feedItems.shift();
    if (oldest && oldest.parentNode === liveFeed) {
      liveFeed.removeChild(oldest);
    }
  }

  // Subtle entry animation handled by CSS transitions if desired, 
  // but for performance we keep it lean.
}

/**
 * Updates the global dashboard stats.
 * @param {Object} stats - Stats object from server.
 */
export function updateStats(stats) {
  if (stats.headBlock) headBlockText.textContent = stats.headBlock;
  if (stats.jackpot) jackpotPoolText.textContent = `${stats.jackpot.toLocaleString()} SATS`;
}

// Global zap handler for the buttons
window.zapPodcast = (url) => {
  console.log(`[V4V] Triggering zap for: ${url}`);
  // This will be linked to WebLN / Alby in Phase 2
  if (window.webln) {
    alert(`WebLN Triggered: Sending zap to ${url}`);
  } else {
    // Open payment modal fallback
    const modal = document.getElementById('paymentModal');
    if (modal) modal.classList.add('active');
  }
};
